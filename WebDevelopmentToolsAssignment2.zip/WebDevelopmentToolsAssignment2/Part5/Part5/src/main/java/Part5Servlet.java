import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 *
 * @author vinithiteshharsora
 */
@WebServlet(urlPatterns = {"/part5.xls"})
public class Part5Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fileName = request.getParameter("fileName");
  
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>HWPart 5</title>");
        out.println("</head>");
        out.println("<body>");

        File file = new File(getServletContext().getRealPath("/files/")+fileName+".xls");
        FileInputStream stream = new FileInputStream(file);
        HSSFWorkbook book = new HSSFWorkbook(stream);
        for(int i = 0 ; i < book.getNumberOfSheets(); i++){
            HSSFSheet Sheet = book.getSheetAt(i);
            out.println("<table>");
            for(int j = 0; j < Sheet.getLastRowNum(); j++){
                HSSFRow row = Sheet.getRow(j);
                out.println("<tr>");
                for(int k  = 0; k < row.getLastCellNum(); k++){
                    HSSFCell Cell = row.getCell(k);
                    String str = Cell.toString();
                    if(j == 0){
                        out.println("<th>"+str);
                    }else{
                        out.println("<td>"+str);
                    }
                }
            }
            out.println("</table>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}