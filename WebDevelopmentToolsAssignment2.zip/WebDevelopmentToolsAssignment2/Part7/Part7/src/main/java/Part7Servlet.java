import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author vinithiteshharsora
 */
@WebServlet(name = "Part7Servlet" , urlPatterns = {"/part7.html"})
public class Part7Servlet extends HttpServlet {
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
            response.setContentType("/part7.html");
            PrintWriter out = response.getWriter();
            Enumeration<String> enumeration = request.getParameterNames();
            while(enumeration.hasMoreElements()){
                String str = enumeration.nextElement();                
                if (str.equals("acadterm")) {
                    out.println("<br>");
                    out.println("Academic Term : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("year")) {
                    out.println("<br>");
                    out.println("Academic Year : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("status")) {
                    out.println("<br>");
                    out.println("Status : ");
                    String[] temp = request.getParameterValues(str);
                    for (String s : temp) {
                        out.println(s + " , ");
                    }
                    
                }

                if (str.equals("name")) {
                    out.println("<br>");
                    out.println("Student Name is :");
                    out.println(request.getParameter(str));
                }

                if (str.equals("relationship")) {
                    out.println("<br>");
                    out.println("Relationship to Employee is :");
                    out.println(request.getParameter(str));
                }

                if (str.equals("nuid")) {
                    out.println("<br>");
                    out.println("Student NUID is :");
                    out.println(request.getParameter(str));
                }

                if (str.equals("ename")) {
                    out.println("<br>");
                    out.println("Employee Name is :");
                    out.println(request.getParameter(str));
                }

                if (str.equals("department")) {
                    out.println("<br>");
                    out.println("Department is : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("location")) {
                    out.println("<br>");
                    out.println("Campus Location is : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("phoneNumber")) {
                    out.println("<br>");
                    out.println("Phone Number is : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("sname")) {
                    out.println("<br>");
                    out.println("Supervisor Name is : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("school")) {
                    out.println("<br>");
                    out.println("School or program is : ");
                    out.println(request.getParameter(str));
                }

                if (str.equals("cnumber")) {
                    out.println("<br><br>");
                    out.println("Course No is :");
                    out.println(request.getParameter(str));
                }

                if (str.equals("cname")) {
                    out.println("<br>");
                    out.println("Course Name is : ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("ssign")) {
                    out.println("<br>");
                    out.println("Supervisor Signature is : ");
                    out.println(request.getParameter(str));

                }
                
                
                if (str.equals("credit")) {
                    out.println("<br>");
                    out.println("Credit Hrs is : ");
                    out.println(request.getParameter(str));
                }
                
                
                if (str.equals("days")) {
                    out.println("<br>");
                    out.println("Day(s) is: ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("time")) {
                    out.println("<br>");
                    out.println("Time(a.m/p.m) is: ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("cnumber1")) {
                    out.println("<br><br>");
                    out.println("Course No is:");
                    out.println(request.getParameter(str));
                }

                if (str.equals("cname1")) {
                    out.println("<br>");
                    out.println("Course Name is: ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("ssign1")) {
                    out.println("<br>");
                    out.println("Supervisor Signature is : ");
                    out.println(request.getParameter(str));
                }
                
                
                if (str.equals("credit1")) {
                    out.println("<br>");
                    out.println("Credit Hrs is: ");
                    out.println(request.getParameter(str));
                }
                
                
                if (str.equals("days1")) {
                    out.println("<br>");
                    out.println("Day(s) is : ");
                    out.println(request.getParameter(str));
                    
                }
                
                if (str.equals("time1")) {
                    out.println("<br>");
                    out.println("Time(a.m/p.m) is : ");
                    out.println(request.getParameter(str));

                }
                
                if (str.equals("cnumber2")) {
                    out.println("<br><br>");
                    out.println("Course No is :");
                    out.println(request.getParameter(str));
                }

                if (str.equals("cname2")) {
                    out.println("<br>");
                    out.println("Course Name is : ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("ssign2")) {
                    out.println("<br>");
                    out.println("Supervisor Signature is : ");
                    out.println(request.getParameter(str));
                }
                
                
                if (str.equals("credit2")) {
                    out.println("<br>");
                    out.println("Credit Hrs is : ");
                    out.println(request.getParameter(str));
                }
                
                
                if (str.equals("days2")) {
                    out.println("<br>");
                    out.println("Day(s) is : ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("time2")) {
                    out.println("<br>");
                    out.println("Time(a.m/p.m) is: ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("esign")) {
                    out.println("<br><br>");
                    out.println("Employee Signature is: ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("date3")) {
                    out.println("<br>");
                    out.println("Date is : ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("approval")) {
                    out.println("<br><br>");
                    out.println("HRM Approval is : ");
                    out.println(request.getParameter(str));
                }
                
                if (str.equals("date4")) {
                    out.println("<br>");
                    out.println("Date is: ");
                    out.println(request.getParameter(str));
                }
                
                out.println("<br><br>"); 
            }
        } catch (Exception e) {
            System.out.println("EXCEPTION: " + e.getMessage());
        }
    }
}