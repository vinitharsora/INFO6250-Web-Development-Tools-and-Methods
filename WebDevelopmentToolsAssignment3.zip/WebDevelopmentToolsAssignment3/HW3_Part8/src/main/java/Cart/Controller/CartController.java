package Cart.Controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author vinithiteshharsora
 */
public class CartController extends HttpServlet {


protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getServletPath();
        
        switch (action) {
            case "/add":
                addCart(request, response);
                break;
            case "/view":
                viewCart(request, response);
                break;
            case "/remove":
                removeCart(request, response);
                break;
            case "/book":
                books(request, response);
                break;
            case "/computer":
                computer(request, response);
                break;
            case "/music":
                music(request, response);
                break;
            case "/cart":
                defaultCart(request, response);
                break;
            default:
                defaultCart(request, response);
                break;
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void addCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         HttpSession session = request.getSession();
        ArrayList<String> cart = (ArrayList<String>) session.getAttribute("cart");
        if (cart == null)
            cart = new ArrayList<>();
        String[] goods = request.getParameterValues("data");
        if (goods == null){
            session.setAttribute("list",goods);
            RequestDispatcher dispatcher = request.getRequestDispatcher("notification.jsp");
                dispatcher.forward(request, response);
        }
        for (String s : goods) {
            cart.add(s);
        }
        session.setAttribute("list",goods);
        session.setAttribute("cart", cart);
        RequestDispatcher dispatcher = request.getRequestDispatcher("notification.jsp");
        dispatcher.forward(request, response);
    }

    private void viewCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        ArrayList<String> cart = (ArrayList<String>)session.getAttribute("cart");
        if(cart == null)
            cart = new ArrayList<>();
        RequestDispatcher dispatcher = request.getRequestDispatcher("cart.jsp");
        dispatcher.forward(request, response);
    }

    private void removeCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String[] remove = request.getParameterValues("remove");
        ArrayList<String> cart = (ArrayList<String>) session.getAttribute("cart");
        Iterator iter = cart.iterator();
        if (remove != null) {
            for (String s : remove) {
                while (iter.hasNext()) {
                    if (s.equals((String) iter.next())) {
                        iter.remove();
                        break;
                    }
                }
                iter = cart.iterator();
            }
        }
        session.setAttribute("cart",cart);
        RequestDispatcher dispatcher = request.getRequestDispatcher("cart.jsp");
        dispatcher.forward(request, response);
    }

    private void books(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         RequestDispatcher dispatcher = request.getRequestDispatcher("Books.jsp");
         dispatcher.forward(request, response);
    }
    
    private void defaultCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("shopping.jsp");
        dispatcher.forward(request, response);
    }

    private void computer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("Computers.jsp");
         dispatcher.forward(request, response);
    }

    private void music(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("Music.jsp");
         dispatcher.forward(request, response);
    }
}
