import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class DisplayTutionWaiverFormInputPart extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {

	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String acadyr = request.getParameter("acadyr");
		String empstatus = request.getParameter("empstatus");
		String studentname = request.getParameter("studentname");
		String relationship = request.getParameter("relationship");
		String studentnuid = request.getParameter("studentnuid");
		String empname = request.getParameter("empname");
		String empid = request.getParameter("empid");
		String dept = request.getParameter("dept");
		String campus = request.getParameter("campus");
		String[] acadterm = request.getParameterValues("acadterm");
		String phone = request.getParameter("phone");
		String supervisorname = request.getParameter("supervisorname");
		String[] program = request.getParameterValues("program");
		String courseno = request.getParameter("courseno");
		String coursename = request.getParameter("coursename");
		String supervisorsign = request.getParameter("supervisorsign");
		String credithrs = request.getParameter("credithrs");
		String day = request.getParameter("day");
		String time = request.getParameter("time");
		String empsign = request.getParameter("empsign");
		String empdate = request.getParameter("empdate");
		String hrmapproval = request.getParameter("hrmapproval");
		String hrmdate = request.getParameter("hrmdate");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Display Tution Waiver Form Input</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p>Academic Term: ");
		for (String a : acadterm) {
			out.println(a + " ");
		}
		out.println("</p>");
		out.println("<p>Academic Year: " + acadyr + "</p>");
		out.println("<p>Employee Status: " + empstatus + "</p>");
		out.println("<p>Student's Name: " + studentname + "</p>");
		out.println("<p>Relationship to Employee: " + relationship + "</p>");
		out.println("<p>Student's NUID: " + studentnuid + "</p>");
		out.println("<p>Employee's Name: " + empname + "</p>");
		out.println("<p>Employee's Id: " + empid + "</p>");
		out.println("<p>Department: " + dept + "</p>");
		out.println("<p>Campus Location: " + campus + "</p>");
		out.println("<p>Phone Number: " + phone + "</p>");
		out.println("<p>Supervisor's Name: " + supervisorname + "</p>");				
		out.println("<p>School or Program: ");
		for (String pr : program) {
			out.println(pr + " ");
		}
		out.println("</p>");
		out.println("<p>Course No: " + courseno + "</p>");
		out.println("<p>Course Name:: " + coursename + "</p>");
		out.println("<p>Supervisor Signature: " + supervisorsign + "</p>");
		out.println("<p>Credit Hrs: " + credithrs + "</p>");
		out.println("<p>Day: " + day + "</p>");
		out.println("<p>Time(a.m/p.m): " + time + "</p>");
		out.println("<p>Employee Signature: " + empsign + "</p>");
		out.println("<p>Date: " + empdate + "</p>");
		out.println("<p>HRM Approval: " + hrmapproval + "</p>");
		out.println("<p>Date: " + hrmdate + "</p>");
		out.println("</body>");
		out.println("</html>");
	}
}
