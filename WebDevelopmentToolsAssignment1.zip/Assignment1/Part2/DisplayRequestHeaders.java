import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;


public class DisplayRequestHeaders extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
            out.println("<h1>Headers -----> Enumeration getHeaderNames()</h1> ");
            out.println("<br/>");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
        String headerName = headerNames.nextElement();
            out.print("Header Name: <em>" + headerName);
        String headerValue = request.getHeader(headerName);
            out.print("</em>, Header Value: <em>" + headerValue);
            out.println("</em><br/>");
        }
            out.println("<hr>");
            out.println("<h1>Headers -----> Enumeration getHeaders(String name)</h1> ");
            out.println("<br/>");
        String ht = request.getHeader("host");
            out.print("</em>Header Value for host:- <em>" + ht);
            out.println("<br/>");
	    String cn = request.getHeader("connection");
            out.print("</em>Header Value for connection:- <em>" + cn);
    }
}
