import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;


public class DisplayGetXMethodsHeader extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		out.println("<!doctype html public \"-//W3C//DTD HTML 4.0 Transitional//EN\">"); 

		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<title>GetMethods</title>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println("<h1>ServletRequest ---></h1>");

		if(request.getAttributeNames() != null)
		{out.println("1. getAttributeNames : "+request.getAttributeNames().toString());}
		out.println("<br><br>");

		if(request.getLocalAddr() != null)
		{out.println("2. getLocalAddr : "+request.getLocalAddr().toString());} 
		out.println("<br><br>");
		
		if(request.getLocale() != null)
		{out.println("3. getLocale : "+request.getLocale().toString());}
		out.println("<br><br>");
		
		if(request.getLocales() != null) 
		{out.println("4. getLocales : "+request.getLocales().toString());}
		out.println("<br><br>");
		
		if(request.getLocalName() != null)
		{out.println("5.getLocalName : "+request.getLocalName().toString());} 
		out.println("<br><br>");
		
		if(request.getProtocol() != null)
		{out.println("6. getProtocol : "+request.getProtocol().toString());} 
		out.println("<br><br>");
		
		if(request.getParameterMap() != null)
		{out.println("7. getParameterMap : "+request.getParameterMap().toString());}
		out.println("<br><br>");
		 
		if(request.getParameterNames() != null)
		{out.println("8. getParameterNames : "+request.getParameterNames().toString());}
		out.println("<br><br>");

		if(request.getServerName() != null)
		{out.println("9. getServerName : "+request.getServerName().toString());} 
		out.println("<br><br>");
	
		if(request.getServletContext() != null)
		{out.println("10. getServletContext : "+request.getServletContext().toString());} 
		out.println("<br><br>");

		out.println("<hr>");
		out.println("<h1>HttpServletRequest ---></h1>");

		if(request.getCookies() != null)
		{out.println("1. getCookies : "+request.getCookies().toString());} 
		out.println("<br><br>");
	
		if(request.getHeaderNames() != null) 
		{out.println("2. getHeaderNames : "+request.getHeaderNames().toString());} 
		out.println("<br><br>");

		if(request.getMethod() != null) 
		{out.println("3. getMethod : "+request.getMethod().toString());} 
		out.println("<br><br>");
		
		if(request.getRequestURL() != null) 
		{out.println("4. getRequestURL : "+request.getRequestURL().toString());} 
		out.println("<br><br>");

		if(request.getContextPath() != null) 
		{out.println("5. getContextPath : "+request.getContextPath().toString());} 
		out.println("<br><br>");
		  
		if(request.getSession() != null) 
		{out.println("6. getSession : "+request.getSession().toString());} 
		out.println("<br><br>");

		if(request.getRequestedSessionId() != null)
		{out.println("7. getRequestedSessionId : "+request.getRequestedSessionId().toString());} 
		out.println("<br><br>");
		
		if(request.getRequestURI() != null) 
		{out.println("8. getRequestURI : "+request.getRequestURI().toString());} 
		out.println("<br><br>");
		
		if(request.getRequestURL() != null) 
		{out.println("9. getRequestURL : "+request.getRequestURL().toString());} 
		out.println("<br><br>");

		if(request.getServletPath() != null)
		{out.println("10. getServletPath : "+request.getServletPath().toString());}
		 out.println("<br><br>");

		out.println("</BODY>");
		out.println("</HTML>");
	}
	
		public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		doGet(request, response);
	}
	
	
}